<?php
/*
 Plugin Name: Custom Upload Dir
 Plugin URI: http://wordpress.org/extend/plugins/custom-upload-dir/
 Description: Lets you configure where uploaded files are stored on the server. 
 Version: 2.5
 Author: Ulf Benjaminsson
 Author URI: http://www.ulfben.com/

 Changelog v.2.5 (2008-11-15)
 	Support for WP 2.7
 	Added 'post_author'	
 	Fixed 'post_title' (broken since WP 2.4)
 	Fixed issue with use_yearmonth overriding post date	
 	Lots of small(ish) updates
 
 Changelog v.2.0 (2007-10-19)
	Mediacaster compability
	Configuration page
	Massive code overhaul
	Name change
	
 Changelog v1.0 (daily upload dir):
	Bare necessities, hardcoded directory structure
 	Thanks to futurix for some code and idea: http://wordpress.org/support/topic/119565 
 */

if(function_exists('register_activation_hook') && function_exists('register_deactivation_hook')) {	
	register_activation_hook(__FILE__, 'custom_upload_dir_set_options');
	register_deactivation_hook(__FILE__, 'custom_upload_dir_delete_options');		
} 

add_filter('upload_dir', 'custom_upload_dir');
add_action('admin_menu', 'custom_upload_dir_add_option_page');

function custom_upload_dir_add_option_page() {
	if ( function_exists('add_options_page') ) {
		add_options_page('Custom Upload Dir Settings', 'Custom Upload Dir', 8, __FILE__, 'custom_upload_dir_option_page');
		add_filter('plugin_action_links', 'custom_upload_dir_add_plugin_actions', 10, 2 );
	}
}

function custom_upload_dir_get_version(){
	if(function_exists('get_plugin_data')){
		$plugin_data = get_plugin_data(__FILE__);
		return "".$plugin_data['Version'];
	}
	return "2.5";
}

function custom_upload_dir_add_admin_footer(){ //shows some plugin info at the footer of the config screen.
	$plugin_data = get_plugin_data(__FILE__);
	printf('%1$s plugin | Version %2$s | by %3$s<br />', $plugin_data['Title'], $plugin_data['Version'], $plugin_data['Author']);
}
	
function custom_upload_dir_add_plugin_actions($links, $file){ //add's a "Settings"-link to the entry on the plugin screen
	static $this_plugin;
	if(!$this_plugin){
		$this_plugin = plugin_basename(__FILE__);
	}	
	if($file == $this_plugin){				
		$settings_link = $settings_link = '<a href="options-general.php?page=custom-upload-dir/custom_upload_dir.php">' . __('Settings') . '</a>';
		array_unshift($links, $settings_link);	
	}
	return $links;		
}

function custom_upload_dir_set_options(){
	$subdirs = array(
			'0' => 'year',
			'1' => 'month',
			'2' => 'day',
			'3' => 'post_title',
			'4' => 'post_author'
			//'5' => 'post_category' TODO - how can I get categories from a post, outside the loop?
		);	
	update_option('custom_upload_dir', $subdirs);
	update_option('custom_upload_mediacaster_comp', '0'); //mediacaster compability flag
}

function custom_upload_dir_delete_options(){
	delete_option('custom_upload_dir');
	delete_option('custom_upload_mediacaster_comp');
}

function custom_upload_dir_get_authorname($id){	//taken from http://guff.szub.net/source/get-author-profile.php
    global $wpdb;   
    if(!is_numeric($id)){	   
        return '';
    }
    $author = @$wpdb->get_row("SELECT * FROM $wpdb->users WHERE ID = '$id' LIMIT 1");
    $wpdb->hide_errors();
    $metavalues = $wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->usermeta WHERE user_id = '$id'");
    $wpdb->show_errors();

    if($metavalues){
        foreach ($metavalues as $meta) {
            @ $value = unserialize($meta->meta_value);
            if($value === FALSE){
                $value = $meta->meta_value;
            }
            $author->{$meta->meta_key} = $value;
            if ( $wpdb->prefix . 'user_level' == $meta->meta_key ){
                $author->user_level = $meta->meta_value;
            }
        }
    }        
    /*$author->display_name;
    $author->first_name;    
    $author->last_name;                
    $author->nickname;*/          
    return sanitize_title($author->display_name);   
}


/*
$wp_default_upload
	[path] => /home/user/server.com/blog/wp-content/uploads/2008/11 
	[url] => http://blog.server.com/wp-content/uploads/2008/11 
	[subdir] => /2008/11 
	[basedir] => /home/user/server.com/blog/wp-content/uploads 
	[baseurl] => http://blog.server.com/wp-content/uploads 
	[error] => 
*/
function custom_upload_dir($wp_default_upload){	
	$post_id = $_REQUEST['post_id'];
	if($wp_default_upload['error'] || !is_numeric($post_id)){
		wp_die($wp_default_upload['error']);
	}	
	$time = current_time('timestamp');
	$subdirs = get_option('custom_upload_dir');	
	$mccompatible = get_option('custom_upload_mediacaster_comp');
	$use_yearmonth = get_option('uploads_use_yearmonth_folders');
	$customdir = '';		
	$post = get_post($post_id);			
	$postGotDate = ($post->post_date != "0000-00-00 00:00:00" && $post->post_date);
	$name = $post->post_name;//post_name == slug				
	if(empty($name)){ 
		$name = sanitize_title($post->post_title);
	}
	if(empty($name)){
		$name = $post->ID;
	}
	if($postGotDate) { //only use the post_date if it has been defined (ie. published or manually altered)		
		$time = strtotime($post->post_date); 
		if($use_yearmonth){ //custom upload dir put stuff according to the post's timestamp. If yearmonth is on, we need to override it.			
			$currentYearMonth = $wp_default_upload['subdir'];
			$postYearMonth = '/'.date("Y", $time).'/'.date("m", $time);						
			$wp_default_upload['path'] = str_replace($currentYearMonth, $postYearMonth, $wp_default_upload['path']);
			$wp_default_upload['url'] 	= str_replace($currentYearMonth, $postYearMonth, $wp_default_upload['url']);
			$wp_default_upload['subdir'] = $postYearMonth;									
		}			
	}		
		
	if($mccompatible && ($post->post_status == 'static' || $post->post_type == 'page')) {//force compability with mediacaster plugin					
		if($use_yearmonth){ //override yearmonth-settings, for mediacaster compability
			$yearmonth = date("Y", $time).'/'.date("m", $time); //ex: 2007/10
			$wp_default_upload['path'] = untrailingslashit(str_replace($yearmonth, '', $wp_default_upload['path']));  
			$wp_default_upload['url'] = untrailingslashit(str_replace($yearmonth, '', $wp_default_upload['url']));
		}		
		$customdir = "/".$name;			
		if ( $post->post_parent != 0 ) {
			while ( $post->post_parent != 0 ){
				$post = get_post($post->post_parent);	
				$customdir = "/".$name . $customdir;
			}
		}			
	}else{				
		for($i = 0; $i < count($subdirs); $i++){		
			if(!empty($subdirs[$i]) && $subdirs[$i] != 'none'){
				$customdir = trailingslashit($customdir);
				if($subdirs[$i] == 'year'){
					if($i == 0 && $use_yearmonth){ //avoid redundant year					
						continue;
					} else {
						$customdir .= date("Y", $time);
					} 
				} else if($subdirs[$i] == 'month'){
					if($i == 1 && $use_yearmonth) { //avoid redundant month						
						continue;					
					} else {						
						$customdir .= date("m", $time);					
					}
				} else if($subdirs[$i] == 'day'){
					$customdir .= date("d", $time);
				} else if($subdirs[$i] == 'post_title'){
					if(!empty($name)){											 
						$customdir .= $name;
					}	//$message = __('Custom Upload Dir: post title required.<br><strong>Name</strong> and <strong>save</strong> the post before uploading.');	//return array('error' => $message);				
					else {
						//will fail silently and simply skip the post_title-directory.						
						//wp_die("No post name.\npost_name = $post->post_name \npost_title = $post->post_title \n ID = $post_id");
					}
				} else if($subdirs[$i] == 'post_author'){
					$author = custom_upload_dir_get_authorname($post->post_author);										
					if(!empty($author)){
						$customdir .= $author;
					}
				}		
			}		
		}		
	}
	$wp_default_upload['path'] .= untrailingslashit($customdir);
	$wp_default_upload['url'] .= untrailingslashit($customdir); 
	
	if ( ! wp_mkdir_p( $wp_default_upload['path'] ) ) {
		$message = sprintf(__('Unable to create directory %s. Is its parent directory writable by the server?'), $wp_default_upload['path']);		
		return array('error' => $message);
	}	
	return $wp_default_upload;
}

function custom_upload_dir_option_page() {
	if(function_exists('current_user_can') && !current_user_can('manage_options') ){
		die(__('Cheatin&#8217; uh?'));
	}
	add_action('in_admin_footer', 'custom_upload_dir_add_admin_footer');
	$subdirs = get_option('custom_upload_dir');	
	$mccompability = get_option('custom_upload_mediacaster_comp');
	$basepath = get_option('upload_path');
	if(isset($_POST['submit'])) {
		$use_yearmonth = ($_POST['uploads_use_yearmonth_folders'] == 1);		
		update_option('uploads_use_yearmonth_folders', $use_yearmonth);	
		
		(!isset($_POST['level0']) || $use_yearmonth) 		? $subdirs[0] = 'year' 	: $subdirs[0] = $_POST['level0'];
		(!isset($_POST['level1']) || $use_yearmonth) 		? $subdirs[1] = 'month' : $subdirs[1] = $_POST['level1'];
		(!isset($_POST['level2'])) 		? $subdirs[2] = 'day' 				: $subdirs[2] = $_POST['level2'];
		(!isset($_POST['level3'])) 		? $subdirs[3] = 'post_title'		: $subdirs[3] = $_POST['level3'];							
		(!isset($_POST['mc_mode'])) 	? $mccompability = "0" 				: $mccompability = $_POST['mc_mode'];		
		(isset($_POST['upload_path'])) 	? $basepath = $_POST['upload_path'] : false; 
		if($mccompability == 1)	{
			$basepath = 'media';
			$subdirs[0] = 'year';
			$subdirs[1] = 'month';
			$subdirs[2] = 'day';
			$subdirs[3] = 'post_title';			 
		}
		
		$clean = array();
		for($i = 0; $i < count($subdirs); $i++){			
			if(isset($subdirs[$i]) && $subdirs[$i] != 'none' && $subdirs[$i] != ''){
				 $clean[] = $subdirs[$i]; //equivalent of push_back in other languages.		
			}			
		}
		while(count($clean) < 4){
			$clean[] = 'none';
		}
		$subdirs = $clean;	
			
		update_option('upload_path', $basepath);
		update_option('custom_upload_dir', $subdirs);
		update_option('custom_upload_mediacaster_comp', $mccompability);
		echo '<div id="message" class="updated fade"><p>';		
		echo '<font color="black">Upload directory updated...</font><br />';
		if(in_array('post_title', $subdirs)){
			echo '<font color="orange">Please <em>name</em> and <em>save</em> your post <strong>before</strong> uploading attachments.</font><br />';
		}		
		if($mccompability){
			echo '<font color="orange">Forcing Mediacaster compatible settings.</font><br />';			
		} 
		echo '</p></div>';
	}	
	?>

<div class="wrap">
<h2>Customize upload path:</h2>
<p>If avaliable, Custom Upload Dir will use the <strong>post's</strong> timestamp when creating yearly, monthly, or daily folders.</p>
<form method="post">
<fieldset class="options">
<table class="optiontable">
<?php
	$usecomp = ''; $usebase = '';
	$use_yearmonth = get_option('uploads_use_yearmonth_folders');
	if($mccompability){
		$usecomp 	= ' checked="checked" ';
		$usebase 	= 'readonly';
	}
	
	print ("<tr>
	<td style='text-align:right;'>Base upload folder:</td>
	<td><input name='upload_path' $usebase type='text' id='upload_path' class='code' value='$basepath' size='40' />
	<br /> Default is <code>wp-content/uploads</code>
	</td>
	</tr>");
	
	$checked = $use_yearmonth ? 'checked="checked"' : '';
	print("<tr>
	<td style='text-align:right;'>&nbsp;</td>
	<td><input name='uploads_use_yearmonth_folders' type='checkbox' id='uploads_use_yearmonth_folders' value='1' $checked /><label for='uploads_use_yearmonth_folders'>&nbsp;". __('Organize my uploads into month- and year-based folders')."</label></td>	
	</tr>");
			
	print ("<tr><td style='text-align:right;'>Sort files under:</td><td>");		
	for($i = 0; $i < 4; $i++){
		$name = 'level'.$i;
		($subdirs[$i] == 'year') 		? $useyear 	= 'SELECTED' 	: $useyear = "";
		($subdirs[$i] == 'month') 		? $usemonth = 'SELECTED' 	: $usemonth = "";
		($subdirs[$i] == 'day') 		? $useday 	= 'SELECTED' 	: $useday = "";
		($subdirs[$i] == 'post_title') 	? $usetitle = 'SELECTED'	: $usetitle = "";
		($subdirs[$i] == 'post_author') ? $useauthor = 'SELECTED'	: $useauthor = "";	
		($subdirs[$i] == 'none') 		? $usenone 	= 'SELECTED'	: $usenone = "";			
					
		if($use_yearmonth || $mccompability) { //force mediacaster compability
			if($i == 0){
				$useyear = "SELECTED";
				$usemonth = "DISABLED"; $useday = "DISABLED"; $usetitle = "DISABLED";	$usenone = "DISABLED";
			} else if ($i == 1) {
				$usemonth = "SELECTED";
				$useyear = "DISABLED"; $useday = "DISABLED"; $usetitle = "DISABLED";	$usenone = "DISABLED";	
			}
			if($mccompability) {
				if($i == 2){
					$useday	= "SELECTED";
					$useyear = "DISABLED"; $usemonth = "DISABLED"; $usetitle = "DISABLED"; $usenone = "DISABLED";	
				} else if ($i == 3) {
					$usetitle = "SELECTED";	
					$useyear = "DISABLED"; $usemonth = "DISABLED"; $useday = "DISABLED"; $usenone = "DISABLED";	
				}
			}
		} 		
		
		print ("<select name='$name'>
			<option $usenone value='none'>none</option>
			<option $useyear value='year'>year</option>
			<option $usemonth value='month'>month</option>
			<option $useday value='day'>day</option>			
			<option $usetitle value='post_title'>post title</option>
			<option $useauthor value='post_author'>post author</option>
			</select>");		
	}
	print('</td></tr>');	
	
	$fullpath = '/'; 	
	($basepath != '') ? $fullpath .= $basepath.'/' : false;
	for($i = 0; $i < count($subdirs); $i++)	{
		($subdirs[$i] != 'none') ?	$fullpath .= '%'.$subdirs[$i].'%/' : false;		
	}	
	
	print ("<tr>
		<td style='text-align:right;'>Custom upload folder:</td>
		<td><input name='custom_example' readonly type='text' class='code' value='$fullpath' class='code' size='60' /></td>
	</tr>");
		
	print("<tr><td style='text-align:right;'>Force <a target='_blank' href='http://www.semiologic.com/software/publishing/mediacaster/'>Mediacaster</a> compability:</td><td><label><input type='checkbox' name='mc_mode' $usecomp value='1'/>&nbsp;(Files added to <strong>pages</strong> will be put in <code>/%upload_base%/%page_title%/</code>)</label></td></tr>");
	print('<tr><td colspan="2" style="text-align:center;"><br><font color="orange">Always <em>name</em> and <em>save</em> your post <strong>before</strong> uploading attachments.</font></td></tr>');
?>	 	
</table>
</fieldset>
<p class="submit"><input type="submit" name="submit" value="<?php _e('Update Settings &raquo;') ?>" /></p>
</div>
</form>
<?php
}
?>