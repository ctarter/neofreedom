=== Custom Upload Dir ===
Contributors: ulfben
Donate link: http://www.amazon.com/gp/registry/wishlist/2QB6SQ5XX2U0N/105-3209188-5640446?reveal=unpurchased&filter=all&sort=priority&layout=standard&x=11&y=10
Tags: upload, organize, files, media 
Requires at least: 2.2
Tested up to: 2.7-beta1
Stable tag: 2.5

Let's you customize where uploaded files are placed.

== Description ==
Allows more useful placement of uploaded files than Wordpress' default month- and year-based folders.
[The screenshots](http://wordpress.org/extend/plugins/custom-upload-dir/screenshots/) says it all.


**Changes in v.2.5 (2008-11-15)**

1. Support for WP 2.7
1. Added 'post_author'	
1. Fixed 'post_title' (broken since WP 2.4)
1. Fixed issue with use_yearmonth overriding post date	
1. Tons of small(ish) updates

**Changes in v.2.0** (2007-10-19)
 
1. Mediacaster compability.
1. Added proper configuration screen
1. Massive code overhaul
1. Name change (previously "Daily Upload Dir")

== Installation ==

1. Extract `wp-custom_upload_dir.php` and transfer it to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Customize your directory structure in `Settings -> Custom Upload Dir`


== Screenshots ==

1. Shows how the upload path corresponds to the post's timestamp.
2. The configuration screen.

== Other Notes ==
Copyright (C) 2007-2008 Ulf Benjaminsson (ulf at ulfben dot com).

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA