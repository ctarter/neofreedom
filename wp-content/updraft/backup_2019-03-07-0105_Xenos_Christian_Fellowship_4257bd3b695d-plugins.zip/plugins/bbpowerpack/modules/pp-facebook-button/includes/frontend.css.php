.fl-node-<?php echo $id; ?> .fl-module-content {
	<?php if ( isset( $settings->alignment ) ) { ?>
	text-align: <?php echo $settings->alignment; ?>;
	<?php } ?>
}