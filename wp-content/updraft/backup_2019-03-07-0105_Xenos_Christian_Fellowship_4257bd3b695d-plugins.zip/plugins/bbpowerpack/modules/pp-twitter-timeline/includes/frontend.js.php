;(function($) {
	$(document).ready(function() {
		if ( 'undefined' !== twttr ) {
			twttr.widgets.load();
		}
	});
})(jQuery);