/**
 * This is an example of an additional script that can be 
 * enqueued using the add_js module method. The files settings.js
 * and frontend.js don't need to be enqueued and will be included 
 * for you automatically.
 */