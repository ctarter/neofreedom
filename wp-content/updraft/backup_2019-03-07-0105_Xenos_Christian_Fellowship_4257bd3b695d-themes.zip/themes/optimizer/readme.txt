-------------------------------------------------------
Image Credits:
-------------------------------------------------------
upgrade_banner.jpg/Used as Slider Image : CC0 by Sven Scheuermeier, https://unsplash.com/search/matterhorn?photo=VNseEaTt9w4
welcome_textbg.jpg/Used as Widget Background: CC0 by Steve Richey, https://unsplash.com/photos/6xqAK6oAeHA/
slide_icon.png :	Created by OptimizerWP and released under GPL v2

All other images in the theme are created by OptimizerWP team and released under GPL v2

-------------------------------------------------------
Fonts, CSS, Javascripts Credits:
-------------------------------------------------------
Font Awesome v4.6.1 (FONT) http://fortawesome.github.io/Font-Awesome/license/
Copyright 2014, Dave Gandy, OFL 1.1 http://scripts.sil.org/OFL

Font Awesome v4.6.1 (CSS)  http://fortawesome.github.io/Font-Awesome/license/
Copyright 2014, Dave Gandy, MIT license - http://opensource.org/licenses/MIT


Animate.css v3.5.1 http://daneden.me/animate
Copyright 2014, Daniel Eden, MIT License, http://www.opensource.org/licenses/mit-license.php


The Final Countdown for jQuery  v2.0.4 http://hilios.github.io/jQuery.countdown/
Copyright 2014, Edson Hilios, MIT License, http://www.opensource.org/licenses/mit-license.php


jQuery Easing  v1.3  http://gsgd.co.uk/sandbox/jquery/easing/
Copyright 2012, George Smith, BSD License, https://opensource.org/licenses/bsd-license.php


Magnific Popup v0.9.9 http://dimsemenov.com/plugins/magnific-popup/
Copyright 2014, Dmitry Semenov, MIT License, http://www.opensource.org/licenses/mit-license.php



jQuery Waypoints v2.0.5 https://github.com/imakewebthings/waypoints
Copyright 2014, Caleb Troughton, MIT License, http://www.opensource.org/licenses/mit-license.php


Sidr v1.1.1 https://github.com/artberri/sidr
Copyright 2015, Alberto Varela, MIT License, http://www.opensource.org/licenses/mit-license.php


waitForImages jQuery Plugin v2.1.0 https://github.com/alexanderdickson/waitForImages
Copyright 2014, Alex Dickson, MIT License, http://www.opensource.org/licenses/mit-license.php


pace v1.0.2 https://github.com/HubSpot/pace/
Copyright 2013, HubSpot, Inc., MIT License, http://www.opensource.org/licenses/mit-license.php


HTML5 Placeholder jQuery Plugin v2.1.0 https://github.com/mathiasbynens/jquery-placeholder
Copyright 2014, Mathias Bynens, MIT License, http://www.opensource.org/licenses/mit-license.php


SmoothScroll for websites v1.2.1 https://github.com/galambalazs/smoothscroll-for-websites
Copyright 2015, Balazs Galambosi, MIT License, http://www.opensource.org/licenses/mit-license.php


Jquery matchHeight http://brm.io/jquery-match-height/
Copyright 2014, liabru, MIT License, http://www.opensource.org/licenses/mit-license.php


miniTip v1.5.3 http://goldfirestudios.com
Copyright 2011, James Simpson, MIT License, http://www.opensource.org/licenses/mit-license.php


jQuery Nivo Slider v3.2, http://nivo.dev7studios.com
Copyright 2012, Dev7studios, MIT License, http://www.opensource.org/licenses/mit-license.php


Unveil v1.5.3 http://luis-almeida.github.com/unveil
Copyright 2013, Luis Almeida, MIT License, http://www.opensource.org/licenses/mit-license.php


FileSaver.js v3.2, https://github.com/eligrey/FileSaver.js/
Copyright 2016, Eli Grey, MIT License, http://www.opensource.org/licenses/mit-license.php


Fotorama v4.5.1, https://github.com/eligrey/FileSaver.js/
Copyright 2016, Artem Polikarpov, MIT License, http://www.opensource.org/licenses/mit-license.php


