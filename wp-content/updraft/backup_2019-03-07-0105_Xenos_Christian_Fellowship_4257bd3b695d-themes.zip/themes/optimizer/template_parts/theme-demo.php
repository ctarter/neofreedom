


<div class="home_wrap layer_wrapper wpdemowidgets">
	<div class="fixed_wrap fixindex">
		<div id="frontsidebar" class="frontpage_sidebar">    
			<?php the_widget( 'optimizer_front_about'); ?>
            <?php the_widget( 'optimizer_front_blocks'); ?>
            <?php the_widget( 'optimizer_front_text'); ?>
            <?php the_widget( 'optimizer_front_posts'); ?>
  		</div>
	</div>
</div><!--layer_wrapper class END-->